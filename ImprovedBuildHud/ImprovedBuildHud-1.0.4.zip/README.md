# Improved Build Hud
##### by RandyKnapp
Adds the total number you can build and your current inventory amount after the required amount in the build hud. Can optionally set the color and custom format.

Source: [Github](https://github.com/RandyKnapp/ValheimMods/ImprovedBuildHud/)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)

Copy ImprovedBuildHud.dll into the BepInEx/plugins folder