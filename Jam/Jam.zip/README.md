# Jam v1.0.3
##### by RandyKnapp
Adds more jam to the game:

**Raspberry Jam x4:** (8 Raspberries) Lasts 1200 seconds, gives 15 max HP, 25 max stamina and 1HP regen per second  
**Honey Raspberry Jam **x4**:** (8 Raspberries, 4 Honey) Lasts 1000 seconds, gives 20 max HP, 30 max stamina and 5HP regen per second  
  
**Blueberry Jam **x4**:** (8 Blueberries) Lasts 1200 seconds, gives 20 max HP, 25 max stamina and 1HP regen per second  
**Honey Blueberry Jam **x4**:** (8 Blueberries, 4 Honey) Lasts 1000 seconds, gives 25 max HP, 30 max stamina and 5HP regen per second  
  
**Cloudberry Jam **x4**:** (8 Cloudberries) Lasts 1200 seconds, gives 20 max HP, 35 max stamina and 1HP regen per second  
**Honey Cloudberry Jam **x4**:** (8 Cloudberries, 4 Honey) Lasts 1000 seconds, gives 25 max HP, 40 max stamina and 5HP regen per second  
  
**Kings Jam **x4**:** (8 Raspberries, 8 Cloudberries) Lasts 1200 seconds, gives 30 max HP, 40 max stamina and 2HP regen per second  
**Nordic Jam **x4**:** (8 Blueberries, 8 Cloudberries) Lasts 1200 seconds, gives 30 max HP, 40 max stamina and 2HP regen per second

Source: [Github](https://github.com/RandyKnapp/ValheimMods)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)

Copy the files in the "files" folder to a new folder called "Jam" in your BepInEx plugins folder.