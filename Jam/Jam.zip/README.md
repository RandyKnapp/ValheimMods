# Jam
##### by RandyKnapp
Adds more jam to the game

Source: [Github](https://github.com/RandyKnapp/ValheimMods)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)