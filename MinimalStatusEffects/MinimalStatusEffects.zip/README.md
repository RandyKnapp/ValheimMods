# Minimal Status Effects
##### by RandyKnapp
Moves the status effect list down below the minimap, shrinks the icons, and compacts the text information.

Source: [Github](https://github.com/RandyKnapp/ValheimMods)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)

Copy MinimalStatusEffects.dll into the BepInEx/plugins folder