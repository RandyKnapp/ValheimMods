﻿# Stations Are Containers v1.0.1
Author: RandyKnapp
Source: [Github](https://github.com/RandyKnapp/ValheimMods/tree/main/StationsAreContainers)

Crafting stations now have a built in storage container and can build from it.

Compatible with:
- Auga
- ImprovedBuildHud
- QuickStack

BepInEx config includes:
- Ability to turn off built-in container on a per-station basis
- Ability to configure the size of the container's inventory on a per-station basis

Installation:
- Nexus: Drop the StationsAreContainers.dll right into your BepInEx/plugins folder
- ThunderStore: Use r2modman to install, or manually drop the dll into your BepInEx/plugins folder

### Changelist

1.0.1
- Minor changes to be more compatible with EpicLoot