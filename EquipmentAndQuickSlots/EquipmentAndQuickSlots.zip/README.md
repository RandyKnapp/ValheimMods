# Equipment and Quick Slots
##### by RandyKnapp
Give equipped items their own dedicated inventory slots, plus three more hotkeyable quick slots.

Source: [Github](https://github.com/RandyKnapp/ValheimMods/EquipmentAndQuickSlots/)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)

Copy EquipmentAndQuickSlots.dll into the BepInEx/plugins folder