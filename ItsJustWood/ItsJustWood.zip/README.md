# It's Just Wood!
##### by RandyKnapp
> Ever get frustrated that you can't fuel a fire with that stack of nice, fine wood you have in your inventory? Wonder why ancient bark can't make coal? Worry no more!

Convert uncommon wood types to regular wood. Use all wood types to fuel fires and the charcoal kiln.

Source: [Github](https://github.com/RandyKnapp/ValheimMods)

Install with [BepInEx](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)